﻿using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Session1.Services;
using System.Net;

namespace Session1.Controllers
{

    
    [Route("api/[controller]")]
    [ApiController]
    public class SessionController : ControllerBase
    {
        readonly ISessionService _iSessionService;

        public SessionController(ISessionService sessionService)
        {
            _iSessionService = sessionService;
        }

        [HttpGet]
        public IActionResult GetEmployeeDetails() {
            var list = _iSessionService.GetEmployee();
            if (list == null)
            { 
                throw new Exception("List is empty");
            }
            return Ok(list);
        }
    }
}
