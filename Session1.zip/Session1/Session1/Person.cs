﻿namespace Session1
{
    public class Person
    {
        public string PersonName { get; set; }
        public int PersonAge { get; set; }
    }
}
