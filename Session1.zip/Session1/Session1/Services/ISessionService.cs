﻿namespace Session1.Services
{
    public interface ISessionService
    {
        List<string> GetEmployee();
    }
}
