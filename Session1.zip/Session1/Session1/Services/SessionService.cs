﻿namespace Session1.Services
{
    public class SessionService : ISessionService
    {
        readonly IConfiguration _configuration;

        public SessionService(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public List<string> GetEmployee()
        {
            var list = new List<string>();

            list.Add(_configuration["EmployeeInfo:Name"]);
            list.Add(_configuration["EmployeeInfo:Email"]);
            list.Add(_configuration["EmployeeInfo:Phone"]);

            return list;
        }
    }
}
