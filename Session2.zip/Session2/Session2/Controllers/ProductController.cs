﻿using Microsoft.AspNetCore.Mvc;
using Session2.Contents;
using Session2.Services;

namespace Session2.Controllers
{
    public class ProductController : Controller
    {
        readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        public IActionResult Index()
        {
            List<Product> product = _productService.GetProducts();
            return View(product);
        }
        public IActionResult Details(int id)
        {
            Product product = _productService.GetProduct(id);
            return View(product);
        }
    }
}
