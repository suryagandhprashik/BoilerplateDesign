﻿namespace Session2.Models.Product
{
    public class GetAllProductDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public double ProductPrice { get; set; }
        public string ProductImg { get; set; }
    }
}
