﻿using Session2.Contents;

namespace Session2.Repositories
{
    public interface IProductRepository
    {
        List<Product> GetAllProducts();
        Product GetProductById(int id);
    }
}
