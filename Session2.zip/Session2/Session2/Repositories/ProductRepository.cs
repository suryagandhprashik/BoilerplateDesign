﻿using Microsoft.EntityFrameworkCore;
using Session2.Contents;
using Session2.Contexts;
using Session2.Services;

namespace Session2.Repositories
{
    public class ProductRepository : IProductRepository
    {
        readonly AppDbContext _appDbContext;

        public ProductRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        
        public List<Product> GetAllProducts()
        {
            List<Product> product = _appDbContext.Products.ToList();
            return product;
        }

        public Product GetProductById(int id)
        {
            Product product = _appDbContext.Products.FirstOrDefault(p => p.ProductId == id);

            /* var q = (from pd in _appDbContext.Products
                      join od in _appDbContext.Categories on pd.CategoryId equals od.CategoryId
                      orderby pd.ProductId
                      select new
                      {
                          od.CategoryName,
                          pd.ProductName,
                          pd.ProductImg,
                          pd.ProductPrice,
                          pd.ProductDescription

                      }).FirstOrDefault(p => p.Equals(id));

             */
            return product;
        }
    }
}
