﻿
using Session2.Contents;

namespace Session2.Services
{
    public interface IProductService
    {
        Product GetProduct(int id);
        List<Product> GetProducts();
    }
}
