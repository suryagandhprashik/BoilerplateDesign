﻿using MediatR;

namespace Session3.Context.Command
{
    public class DeleteStudentCommand : IRequest<int>
    {
        public int Id { get; set; }
    }
}
