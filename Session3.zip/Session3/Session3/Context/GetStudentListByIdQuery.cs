﻿using Session3.Models;
using MediatR;

namespace Session3.Context
{
    public class GetStudentListByIdQuery : IRequest<Student>
    {
        public int Id { get; set; }
    }
}
