﻿using Session3.Models;
using MediatR;

namespace Session3.Context
{
    public class GetStudentListQuery : IRequest<List<Student>>
    {
    }
}
