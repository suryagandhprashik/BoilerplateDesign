﻿using Session3.Models;
using Session3.Services;
using MediatR;

namespace Session3.Context.Handlers
{
    public class GetAllStudentHandler : IRequestHandler<GetStudentListByIdQuery, Student>
    {
        private readonly IStudentRepository _studentRepository;

        public GetAllStudentHandler(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public async Task<Student> Handle(GetStudentListByIdQuery request, CancellationToken cancellationToken)
        {
            return await _studentRepository.GetStudentById(request.Id);
        }
    }
}
