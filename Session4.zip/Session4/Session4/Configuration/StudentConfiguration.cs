﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Session4.Models;

namespace Session4.Configuration
{
    public class StudentConfiguration : IEntityTypeConfiguration<Student>
    {
        public void Configure(EntityTypeBuilder<Student> builder)
        {
            builder.HasData(
                new Student
                {
                    StudentId = 1,
                    StudentName = "Ramu Kaka",
                    StudentEmail ="ramu@gmail.com",
                    StudentPhone="9876543210",
                    StudentAddress="Sect 11, nerul",
                    StudentCity="Navi mumbai"
                });
        }
    }
}
