﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Session4.Context;
using Session4.Models;
using Session4.Repositories;

namespace Session4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository _studentRepository;
        readonly AppDbContext _context;

        public StudentController(IStudentRepository studentRepository, AppDbContext appDbContext)
        {
            _studentRepository = studentRepository;
            _context = appDbContext;
        }

        /*[HttpPost]
        public async Task<ActionResult<Student>> New(Student student)
        {
            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            *//*_studentRepository.AddStudent(student);*//*

            return CreatedAtAction("GetProduct", new { id = student.StudentId }, student);
        }*/

        

        [HttpGet] 

        public async Task<IActionResult> GetAllStudent()
        {
            List<Student> student = await _studentRepository.GetStudents();

            return Ok(student);
        }


        [HttpPost]
        public async Task<Student> GetStudentById(int id)
        {
            var student = await _studentRepository.GetStudentById(id);

            return student;
        }



    }
}
