﻿using Session4.Models;

namespace Session4.Repositories
{
    public interface IStudentRepository
    {
        
        Task<Student> GetStudentById(int id);
        Task<List<Student>> GetStudents();
        
    }
}
