﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Session4.Context;
using Session4.Models;

namespace Session4.Repositories
{
    public class StudentRepository : IStudentRepository
    {

        readonly AppDbContext _context;

        public StudentRepository(AppDbContext context)
        {
            _context = context;
        }


        public async Task<Student> GetStudentById(int id)
        {
            var student = await _context.Students.FirstOrDefaultAsync(s => s.StudentId == id);
            return student;
        }

        public async Task<List<Student>> GetStudents()
        {
            List<Student> students = await _context.Students.ToListAsync();

            return students;
        }

        
    }
}
