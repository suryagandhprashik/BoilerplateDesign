﻿using Microsoft.EntityFrameworkCore;
using Session5JWT.Configuration;
using Session5JWT.Models;

namespace Session5JWT.Contexts
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            modelBuilder.ApplyConfiguration(new UserEntityConfiguration());
        }

        public DbSet<User> Users { get; set; }
    }
}
