﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ProductAppServer.Content;

namespace ProductAppServer.Configuration
{
    public class CategoryEntityConfiguration : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasData(
                new Category
                {
                    CategoryId = 1,
                    CategoryName = "SmartPhone",
                    CategoryDescription = "All smartphones",

                },
                new Category
                {
                    CategoryId = 2,
                    CategoryName = "Television",
                    CategoryDescription = "All TV's",

                });
        }
    }
}
