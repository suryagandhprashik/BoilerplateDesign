﻿using AutoMapper;
using ProductAppServer.Content;
using ProductServerAPI.Model;
using ProductServerAPI.Model.Users;

namespace ProductServerAPI.Configuration
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<Category, GetAllCategoryDto>().ReverseMap();
            CreateMap<Product, GetProductDetailsDto>().ReverseMap();
            CreateMap<Category, GetCategoryDetailsDto>().ReverseMap();
            CreateMap<Product, GetAllProductDto>().ReverseMap();
            CreateMap<Category, CreateCategoryDto>().ReverseMap();
            CreateMap<Product, CreateProductDto>().ReverseMap();
            CreateMap<ApiUserDto, APIUser>().ReverseMap();
        }
    }
}
