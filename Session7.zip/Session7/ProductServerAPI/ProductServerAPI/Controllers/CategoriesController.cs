﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductAppServer.Content;
using ProductServerAPI.Model;
using ProductServerAPI.Repository;
using System.Diagnostics.Metrics;

namespace ProductServerAPI.Controllers
{
    

    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        readonly private ICategoriesRepository _CategoriesRepository;
        readonly private IMapper _mapper;
        public CategoriesController(ICategoriesRepository CategoriesRepository, IMapper mapper)
        {
            _CategoriesRepository = CategoriesRepository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult> GetCategories()
        {
            List<Category> allCategories = await _CategoriesRepository.GetAllCategories();
            var records = _mapper.Map<List<GetAllCategoryDto>>(allCategories);
            return Ok(records);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<GetCategoryDetailsDto>> GetCategory(int id)
        {
            Category category = await _CategoriesRepository.GetCategoryById(id);
            
            var categoryDto = _mapper.Map<GetCategoryDetailsDto>(category);
            return Ok(categoryDto);

        }

        [HttpPost]
        public async Task<ActionResult> AddCategory(CreateCategoryDto createCountryDto)
        {
            var category = _mapper.Map<Category>(createCountryDto);
            _CategoriesRepository.AddCategory(category);
            return CreatedAtAction("GetCategory", new { id = category.CategoryId }, category);
        }

        [HttpPut("{id:int}")]
        public async Task<ActionResult<Category>> UpdateCategory(int id, Category category)
        {
            try
            {
                if (id != category.CategoryId)
                {
                    return BadRequest("Category ID mismatch");
                }

                var categoryToUpdate = await _CategoriesRepository.GetCategoryById(id);

                if (categoryToUpdate == null)
                {
                    return NotFound($"Category with Id = {id} not found");
                }

                return await _CategoriesRepository.UpdateCategory(category);
            }

            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult<Category>> DeleteCategory(int id)
        {
            try
            {
                var categoryToDelete = await _CategoriesRepository.GetCategoryById(id);

                if (categoryToDelete == null)
                {
                    return NotFound($"category with Id = {id} not found");
                }

                return await _CategoriesRepository.DeleteCategory(id);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }
    }
}
