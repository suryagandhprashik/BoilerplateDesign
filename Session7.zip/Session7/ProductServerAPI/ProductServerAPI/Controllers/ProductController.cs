﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductAppServer.Content;
using ProductServerAPI.Model;
using ProductServerAPI.Repository;

namespace ProductServerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        readonly private IProductRepository _productRepository;
        readonly private IMapper _mapper;
        public ProductController(IProductRepository productRepository, IMapper mapper)
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult> GetProducts()
        {
            List<Product> allProducts = await _productRepository.GetAllProducts();
            var records = _mapper.Map<List<GetAllProductDto>>(allProducts);
            return Ok(records);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<GetProductDetailsDto>> GetProduct(int id)
        {
            Product product = await _productRepository.GetProductById(id);

            var productDto = _mapper.Map<GetProductDetailsDto>(product);
            return Ok(productDto);

        }
        [HttpPost]
        public async Task<ActionResult> AddProduct(CreateProductDto createProductDto)
        {
            var product = _mapper.Map<Product>(createProductDto);
            _productRepository.AddProduct(product);
            return CreatedAtAction("GetProduct", new { id = product.ProductId }, product);
        }


        [HttpDelete("{id:int}")]
        public async Task<ActionResult<Product>> DeleteProduct(int id)
        {
            try
            {
                var productToDelete = await _productRepository.GetProductById(id);

                if (productToDelete == null)
                {
                    return NotFound($"Product with Id = {id} not found");
                }

                return await _productRepository.DeleteProduct(id);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }
    }
}
