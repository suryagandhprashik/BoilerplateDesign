﻿namespace ProductServerAPI.Model
{
    public class CreateCategoryDto
    {
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; } 
    }
}
