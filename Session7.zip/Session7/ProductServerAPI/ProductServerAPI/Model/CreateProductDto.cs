﻿
namespace ProductServerAPI.Model
{
    public class CreateProductDto
    {
        
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public double ProductPrice { get; set; }
        public string ProductImg { get; set; }
        public int CategoryId { get; set; }



    }
}
