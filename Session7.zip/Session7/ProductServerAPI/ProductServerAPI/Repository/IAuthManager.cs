﻿
using Microsoft.AspNetCore.Identity;
using ProductServerAPI.Model.Users;

namespace ProductServerAPI.Repository
{
    public interface IAuthManager
    {
       Task<IEnumerable<IdentityError>> RegisterUser(ApiUserDto userDto);
        Task<AuthresponseDto> Login(Logindto logindto);

        Task<string> CraeteRefreshToken();
        Task<AuthresponseDto> VerifyRefreshToken(AuthresponseDto request);
    }
}
